--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.tpontology DROP CONSTRAINT tmptpontology_pkey;
ALTER TABLE ONLY public.pcrelations DROP CONSTRAINT tmppcrelations_pkey;
ALTER TABLE ONLY public.padcrelations DROP CONSTRAINT tmppadcrelations_pkey;
ALTER TABLE public.tpontology ALTER COLUMN iid DROP DEFAULT;
ALTER TABLE public.pcrelations ALTER COLUMN iid DROP DEFAULT;
ALTER TABLE public.padcrelations ALTER COLUMN iid DROP DEFAULT;
DROP SEQUENCE public.tpontology_iid_seq;
DROP TABLE public.tpontology;
DROP TABLE public.tipoftheday;
DROP TABLE public.stopwords;
DROP TABLE public.prepopulation;
DROP TABLE public.preloadedcategories;
DROP SEQUENCE public.pcrelations_iid_seq;
DROP TABLE public.pcrelations;
DROP SEQUENCE public.padcrelations_iid_seq;
DROP TABLE public.padcrelations;
DROP TABLE public.literaturepreference;
DROP TABLE public.literaturepermissions;
DROP TABLE public.listofontologies;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: listofontologies; Type: TABLE; Schema: public; Owner: textpresso; Tablespace: 
--

CREATE TABLE listofontologies (
    idprefix character varying(64),
    name text
);


ALTER TABLE listofontologies OWNER TO textpresso;

--
-- Name: literaturepermissions; Type: TABLE; Schema: public; Owner: www-data; Tablespace: 
--

CREATE TABLE literaturepermissions (
    userid text,
    preference text
);


ALTER TABLE literaturepermissions OWNER TO "www-data";

--
-- Name: literaturepreference; Type: TABLE; Schema: public; Owner: www-data; Tablespace: 
--

CREATE TABLE literaturepreference (
    userid text,
    preference text
);


ALTER TABLE literaturepreference OWNER TO "www-data";

--
-- Name: padcrelations; Type: TABLE; Schema: public; Owner: textpresso; Tablespace: 
--

CREATE TABLE padcrelations (
    iid integer NOT NULL,
    parent character varying(1023),
    children text
);


ALTER TABLE padcrelations OWNER TO textpresso;

--
-- Name: padcrelations_iid_seq; Type: SEQUENCE; Schema: public; Owner: textpresso
--

CREATE SEQUENCE padcrelations_iid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE padcrelations_iid_seq OWNER TO textpresso;

--
-- Name: padcrelations_iid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: textpresso
--

ALTER SEQUENCE padcrelations_iid_seq OWNED BY padcrelations.iid;


--
-- Name: pcrelations; Type: TABLE; Schema: public; Owner: textpresso; Tablespace: 
--

CREATE TABLE pcrelations (
    iid integer NOT NULL,
    parent character varying(1023),
    child character varying(1023)
);


ALTER TABLE pcrelations OWNER TO textpresso;

--
-- Name: pcrelations_iid_seq; Type: SEQUENCE; Schema: public; Owner: textpresso
--

CREATE SEQUENCE pcrelations_iid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pcrelations_iid_seq OWNER TO textpresso;

--
-- Name: pcrelations_iid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: textpresso
--

ALTER SEQUENCE pcrelations_iid_seq OWNED BY pcrelations.iid;


--
-- Name: preloadedcategories; Type: TABLE; Schema: public; Owner: www-data; Tablespace: 
--

CREATE TABLE preloadedcategories (
    userid text,
    preference text
);


ALTER TABLE preloadedcategories OWNER TO "www-data";

--
-- Name: prepopulation; Type: TABLE; Schema: public; Owner: www-data; Tablespace: 
--

CREATE TABLE prepopulation (
    prepop_id integer,
    mode integer,
    prepop_data text,
    syndatabase text,
    syntablename text,
    syncolname text,
    synwhereclause text
);


ALTER TABLE prepopulation OWNER TO "www-data";

--
-- Name: stopwords; Type: TABLE; Schema: public; Owner: www-data; Tablespace: 
--

CREATE TABLE stopwords (
    words character varying
);


ALTER TABLE stopwords OWNER TO "www-data";

--
-- Name: tipoftheday; Type: TABLE; Schema: public; Owner: www-data; Tablespace: 
--

CREATE TABLE tipoftheday (
    list text
);


ALTER TABLE tipoftheday OWNER TO "www-data";

--
-- Name: tpontology; Type: TABLE; Schema: public; Owner: textpresso; Tablespace: 
--

CREATE TABLE tpontology (
    iid integer NOT NULL,
    eid character varying(60),
    dbxref text,
    term text,
    category character varying(1023),
    attributes text,
    annotationtype character varying(20),
    lexicalvariations text,
    curation_status character varying(20),
    curation_use character varying(60),
    comment text,
    owner character varying(255),
    source character varying(255),
    version character varying(255),
    last_update integer
);


ALTER TABLE tpontology OWNER TO textpresso;

--
-- Name: tpontology_iid_seq; Type: SEQUENCE; Schema: public; Owner: textpresso
--

CREATE SEQUENCE tpontology_iid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tpontology_iid_seq OWNER TO textpresso;

--
-- Name: tpontology_iid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: textpresso
--

ALTER SEQUENCE tpontology_iid_seq OWNED BY tpontology.iid;


--
-- Name: iid; Type: DEFAULT; Schema: public; Owner: textpresso
--

ALTER TABLE ONLY padcrelations ALTER COLUMN iid SET DEFAULT nextval('padcrelations_iid_seq'::regclass);


--
-- Name: iid; Type: DEFAULT; Schema: public; Owner: textpresso
--

ALTER TABLE ONLY pcrelations ALTER COLUMN iid SET DEFAULT nextval('pcrelations_iid_seq'::regclass);


--
-- Name: iid; Type: DEFAULT; Schema: public; Owner: textpresso
--

ALTER TABLE ONLY tpontology ALTER COLUMN iid SET DEFAULT nextval('tpontology_iid_seq'::regclass);


--
-- Data for Name: listofontologies; Type: TABLE DATA; Schema: public; Owner: textpresso
--

COPY listofontologies (idprefix, name) FROM stdin;
\.
COPY listofontologies (idprefix, name) FROM '$$PATH$$/2085.dat';

--
-- Data for Name: literaturepermissions; Type: TABLE DATA; Schema: public; Owner: www-data
--

COPY literaturepermissions (userid, preference) FROM stdin;
\.
COPY literaturepermissions (userid, preference) FROM '$$PATH$$/2086.dat';

--
-- Data for Name: literaturepreference; Type: TABLE DATA; Schema: public; Owner: www-data
--

COPY literaturepreference (userid, preference) FROM stdin;
\.
COPY literaturepreference (userid, preference) FROM '$$PATH$$/2087.dat';

--
-- Data for Name: padcrelations; Type: TABLE DATA; Schema: public; Owner: textpresso
--

COPY padcrelations (iid, parent, children) FROM stdin;
\.
COPY padcrelations (iid, parent, children) FROM '$$PATH$$/2088.dat';

--
-- Name: padcrelations_iid_seq; Type: SEQUENCE SET; Schema: public; Owner: textpresso
--

SELECT pg_catalog.setval('padcrelations_iid_seq', 3487, true);


--
-- Data for Name: pcrelations; Type: TABLE DATA; Schema: public; Owner: textpresso
--

COPY pcrelations (iid, parent, child) FROM stdin;
\.
COPY pcrelations (iid, parent, child) FROM '$$PATH$$/2090.dat';

--
-- Name: pcrelations_iid_seq; Type: SEQUENCE SET; Schema: public; Owner: textpresso
--

SELECT pg_catalog.setval('pcrelations_iid_seq', 12179, true);


--
-- Data for Name: preloadedcategories; Type: TABLE DATA; Schema: public; Owner: www-data
--

COPY preloadedcategories (userid, preference) FROM stdin;
\.
COPY preloadedcategories (userid, preference) FROM '$$PATH$$/2092.dat';

--
-- Data for Name: prepopulation; Type: TABLE DATA; Schema: public; Owner: www-data
--

COPY prepopulation (prepop_id, mode, prepop_data, syndatabase, syntablename, syncolname, synwhereclause) FROM stdin;
\.
COPY prepopulation (prepop_id, mode, prepop_data, syndatabase, syntablename, syncolname, synwhereclause) FROM '$$PATH$$/2093.dat';

--
-- Data for Name: stopwords; Type: TABLE DATA; Schema: public; Owner: www-data
--

COPY stopwords (words) FROM stdin;
\.
COPY stopwords (words) FROM '$$PATH$$/2094.dat';

--
-- Data for Name: tipoftheday; Type: TABLE DATA; Schema: public; Owner: www-data
--

COPY tipoftheday (list) FROM stdin;
\.
COPY tipoftheday (list) FROM '$$PATH$$/2095.dat';

--
-- Data for Name: tpontology; Type: TABLE DATA; Schema: public; Owner: textpresso
--

COPY tpontology (iid, eid, dbxref, term, category, attributes, annotationtype, lexicalvariations, curation_status, curation_use, comment, owner, source, version, last_update) FROM stdin;
\.
COPY tpontology (iid, eid, dbxref, term, category, attributes, annotationtype, lexicalvariations, curation_status, curation_use, comment, owner, source, version, last_update) FROM '$$PATH$$/2096.dat';

--
-- Name: tpontology_iid_seq; Type: SEQUENCE SET; Schema: public; Owner: textpresso
--

SELECT pg_catalog.setval('tpontology_iid_seq', 2116387, true);


--
-- Name: tmppadcrelations_pkey; Type: CONSTRAINT; Schema: public; Owner: textpresso; Tablespace: 
--

ALTER TABLE ONLY padcrelations
    ADD CONSTRAINT tmppadcrelations_pkey PRIMARY KEY (iid);


--
-- Name: tmppcrelations_pkey; Type: CONSTRAINT; Schema: public; Owner: textpresso; Tablespace: 
--

ALTER TABLE ONLY pcrelations
    ADD CONSTRAINT tmppcrelations_pkey PRIMARY KEY (iid);


--
-- Name: tmptpontology_pkey; Type: CONSTRAINT; Schema: public; Owner: textpresso; Tablespace: 
--

ALTER TABLE ONLY tpontology
    ADD CONSTRAINT tmptpontology_pkey PRIMARY KEY (iid);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: listofontologies; Type: ACL; Schema: public; Owner: textpresso
--

REVOKE ALL ON TABLE listofontologies FROM PUBLIC;
REVOKE ALL ON TABLE listofontologies FROM textpresso;
GRANT ALL ON TABLE listofontologies TO textpresso;
GRANT SELECT ON TABLE listofontologies TO "www-data";


--
-- Name: literaturepermissions; Type: ACL; Schema: public; Owner: www-data
--

REVOKE ALL ON TABLE literaturepermissions FROM PUBLIC;
REVOKE ALL ON TABLE literaturepermissions FROM "www-data";
GRANT ALL ON TABLE literaturepermissions TO "www-data";
GRANT SELECT ON TABLE literaturepermissions TO textpresso;


--
-- Name: literaturepreference; Type: ACL; Schema: public; Owner: www-data
--

REVOKE ALL ON TABLE literaturepreference FROM PUBLIC;
REVOKE ALL ON TABLE literaturepreference FROM "www-data";
GRANT ALL ON TABLE literaturepreference TO "www-data";
GRANT SELECT ON TABLE literaturepreference TO textpresso;


--
-- Name: padcrelations; Type: ACL; Schema: public; Owner: textpresso
--

REVOKE ALL ON TABLE padcrelations FROM PUBLIC;
REVOKE ALL ON TABLE padcrelations FROM textpresso;
GRANT ALL ON TABLE padcrelations TO textpresso;
GRANT SELECT ON TABLE padcrelations TO "www-data";
GRANT SELECT ON TABLE padcrelations TO root;


--
-- Name: padcrelations_iid_seq; Type: ACL; Schema: public; Owner: textpresso
--

REVOKE ALL ON SEQUENCE padcrelations_iid_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE padcrelations_iid_seq FROM textpresso;
GRANT ALL ON SEQUENCE padcrelations_iid_seq TO textpresso;
GRANT SELECT ON SEQUENCE padcrelations_iid_seq TO "www-data";


--
-- Name: pcrelations; Type: ACL; Schema: public; Owner: textpresso
--

REVOKE ALL ON TABLE pcrelations FROM PUBLIC;
REVOKE ALL ON TABLE pcrelations FROM textpresso;
GRANT ALL ON TABLE pcrelations TO textpresso;
GRANT SELECT ON TABLE pcrelations TO "www-data";
GRANT SELECT ON TABLE pcrelations TO root;


--
-- Name: pcrelations_iid_seq; Type: ACL; Schema: public; Owner: textpresso
--

REVOKE ALL ON SEQUENCE pcrelations_iid_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE pcrelations_iid_seq FROM textpresso;
GRANT ALL ON SEQUENCE pcrelations_iid_seq TO textpresso;
GRANT SELECT ON SEQUENCE pcrelations_iid_seq TO "www-data";


--
-- Name: preloadedcategories; Type: ACL; Schema: public; Owner: www-data
--

REVOKE ALL ON TABLE preloadedcategories FROM PUBLIC;
REVOKE ALL ON TABLE preloadedcategories FROM "www-data";
GRANT ALL ON TABLE preloadedcategories TO "www-data";
GRANT SELECT ON TABLE preloadedcategories TO textpresso;


--
-- Name: prepopulation; Type: ACL; Schema: public; Owner: www-data
--

REVOKE ALL ON TABLE prepopulation FROM PUBLIC;
REVOKE ALL ON TABLE prepopulation FROM "www-data";
GRANT ALL ON TABLE prepopulation TO "www-data";
GRANT SELECT ON TABLE prepopulation TO textpresso;


--
-- Name: stopwords; Type: ACL; Schema: public; Owner: www-data
--

REVOKE ALL ON TABLE stopwords FROM PUBLIC;
REVOKE ALL ON TABLE stopwords FROM "www-data";
GRANT ALL ON TABLE stopwords TO "www-data";
GRANT SELECT ON TABLE stopwords TO textpresso;
GRANT SELECT ON TABLE stopwords TO root;


--
-- Name: tipoftheday; Type: ACL; Schema: public; Owner: www-data
--

REVOKE ALL ON TABLE tipoftheday FROM PUBLIC;
REVOKE ALL ON TABLE tipoftheday FROM "www-data";
GRANT ALL ON TABLE tipoftheday TO "www-data";
GRANT SELECT ON TABLE tipoftheday TO textpresso;


--
-- Name: tpontology; Type: ACL; Schema: public; Owner: textpresso
--

REVOKE ALL ON TABLE tpontology FROM PUBLIC;
REVOKE ALL ON TABLE tpontology FROM textpresso;
GRANT ALL ON TABLE tpontology TO textpresso;
GRANT SELECT ON TABLE tpontology TO "www-data";
GRANT SELECT ON TABLE tpontology TO root;


--
-- PostgreSQL database dump complete
--

