--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.19 (Ubuntu 10.19-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 10.19 (Ubuntu 10.19-0ubuntu0.18.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP TABLE public.stopwords;
SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: stopwords; Type: TABLE; Schema: public; Owner: www-data
--

CREATE TABLE public.stopwords (
    words character varying
);


ALTER TABLE public.stopwords OWNER TO "www-data";

--
-- Data for Name: stopwords; Type: TABLE DATA; Schema: public; Owner: www-data
--

COPY public.stopwords (words) FROM stdin;
\.
COPY public.stopwords (words) FROM '$$PATH$$/2956.dat';

--
-- Name: TABLE stopwords; Type: ACL; Schema: public; Owner: www-data
--

GRANT SELECT ON TABLE public.stopwords TO textpresso;
GRANT SELECT ON TABLE public.stopwords TO root;


--
-- PostgreSQL database dump complete
--

